char *ler();
void concatenar(char *str1, char *str2);
int tamanho(char *str);
int iguais(char *str1, char *str2);
void liberar(char *str);